# Plunger fit v2 — frozen isolated fixed-contact candidate

Production files are unchanged. No commit or push was made. This candidate passes its sampled static gates but is not a completed plunger or a gameplay-approved change.

Frozen runtime-source-map.json SHA-256:
022605fdccd86d5514c6d34820e3edda1d3d1980c577ae0f05eccff85cb92690

## Structure and appearance

The v1 bored mounting foot, bearing webs, annular boss and four attachment stacks remain. The right apron wing and folded front edge are reformed to maximum X≈2.387, behind the inner rail's right face X≈2.395. The hazard apron right edge matches this channel. Its left edge, inset panels, bolts, leading folds and remaining cabinet structure are preserved. The safety-stripe material receives polygon offset to prevent coplanar flicker; its geometry does not change.

The knob retains its front seat Z-.055 and shaft-axis datum, but its rear cap tapers below the real cross-rail. Shaft length is unchanged. Tip, ferrule, shaft, moving spring seat, both springs, .32 travel and spring kinetics remain unchanged.

Visual inspection of actual full-table and close-up renders against neon-reference.png finds the same right-edge exposed spring/gold knob, silver collection apron, safety stripe and overall playfield arrangement. The knob is smaller and flatter than the original oversized model; the reference is artistic guidance, not dimensional evidence. No claim of photorealistic equivalence is made. Selected views show rest and full pull from oblique, side and top positions.

## Explicit physics changes

1. At the original collider creation slot, replace the unrendered shooter stop X[2.26,2.80], Y[-.1,.7], Z[5.82,5.98] with a visible timber subsection X[2.26,2.80], Y[-1.4,.28], Z[6.15,6.31]. Existing lateral coverage is retained, rather than extending new contact across the whole drain front.
2. Append 26 new static trimeshes AFTER existing ball/reset/outer-rail/board-fastener creation: 22 complete fixed plunger meshes, plus shooter-side surfaces from right apron wing, folded lip, hazard apron and actual front folded cross-rail. Material response is friction .35/restitution .02 for these appended contacts.
3. Apron/cross-rail contacts derive from the exact render meshes, clipped at X≥2.315 (shooter center threshold 2.45 minus ball radius .135). Clipping adds no cap or closure face. This avoids turning the early non-shooter apron into a new drain-saving wall. Retained minimum Z values are wing5.899879, lip6.0225, hazard5.815 and cross-rail6.105; even minus ball radius these are after unchanged drain Z5.05. Full plunger mounting surfaces are not clipped.

The initial overbroad whole-apron-contact draft was not accepted and is retained as rejected-full-apron-contact-source-map.json. No obstacle was deleted to manufacture clearance.

## Moving contact limitation

Ball collision on the moving plunger is still only the original tip convex hull. Knob, shaft, ferrule, moving spring seat and springs do NOT gain ball colliders. Static fit testing does not establish that high or behind-tip balls cannot reach these surfaces. This is shared FIXED-contact work, not complete whole-plunger render/contact matching.

## Verified static evidence

- 101 pull poses, 155 moving convex pieces, zero interference witnesses against 22 actual-app nearfield mesh groups plus fixed plunger meshes: 19,491 narrow-phase queries.
- 15,655 candidate physics queries, zero witnesses. Sensors, ball and the original moving tip collider are excluded from self-interference queries.
- Lathe intervals and annular sectors preserve actual geometry/bored voids. Knurl boxes are separate. C-clip is conservatively enclosed, not treated as an exact filled ring.
- 89,824 conservative spring-bound versus actual-triangle checks pass. Original long-spring/seat and short-spring/guide support contacts are explicit exemptions.
- All 101 poses preserve original tip/ferrule/shaft/seat/spring geometry and positions. Foot seats on the skin at Y.044 and ends at Y.076; the shaft-axis ray remains clear.
- Historical ball/plunger/outer-rail/board-fastener collider handles remain unchanged. launch, setPlungerPull, resetBall, step and nudge method source is identical to baseline.
- Actual 45-degree app render: 486,180 triangles, 600 calls, zero page errors.

These are discrete-pose checks, not a continuous all-motion proof. The nearfield snapshot includes every visible app mesh triangle intersecting X[2.25,2.85], Y[-.2,.5], Z[4.45,6.35] in table coordinates. Fixed meshes use exact installed source geometry; springs are checked conservatively as described.

## Files and execution

runtime-source-map.json is the immutable browser/Node substitution payload. Local plunger.mjs, cabinet.mjs, reference-cabinet.mjs, physics.mjs and plunger-fit-contact.mjs mirror it with repository-relative import rewrites. build-source-map.py records reproducible edits but should not be rerun during someone else's frozen-map regression run.

From repository root:
- node artifacts/pinball/plunger-fit-v2-71245b2/capture.cjs
- node artifacts/pinball/plunger-fit-v2-71245b2/validate.mjs
- node artifacts/pinball/plunger-fit-v2-71245b2/narrowphase.mjs

The capture saves full-table/multiple close views and installed-nearfield.json. The validation outputs include exact contact subset bounds, fixed-surfaces.json and source-map hash. The narrow-phase report lists its scope and results.

For an explicitly requested frozen-map regression run, loader.mjs substitutes mapped production module URLs without writing production files, including the new helper module. Example: node --loader ./artifacts/pinball/plunger-fit-v2-71245b2/loader.mjs --test web/js/pinball/*.test.mjs.

## Pending

Parent owns full old regressions, natural54 and synthetic high/behind-tip comparisons. This worker did not claim those tests pass. Elevated diagnostic drops do not prove natural reachability, and immediate drain-rule exits are not mechanical passage evidence. Missing moving contacts remain open. No physical phone test was performed. No launch-force, state, score, input, or drain-line workaround was introduced.
