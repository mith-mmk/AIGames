import fs from 'node:fs';
import R from '../../../web/js/vendor/rapier3d-0.17.3/rapier.mjs';
import * as T from '../../../web/js/vendor/three-0.180.0/three.module.min.js';
import {MechanicalCabinet} from './cabinet.mjs';
import {PinballPhysics} from './physics.mjs';
import {MechanicalPlunger} from './plunger.mjs';
await R.init();const p=new MechanicalPlunger(),c=new MechanicalCabinet();p.root.position.set(2.53,.175,4.6);c.root.position.z=.2;p.root.updateMatrixWorld(true);c.root.updateMatrixWorld(true);
const zero={x:0,y:0,z:0},identity={x:0,y:0,z:0,w:1},parts=[],obstacles=[];
const snapshot=JSON.parse(fs.readFileSync(new URL('./installed-nearfield.json',import.meta.url)));const names=[];
for(const o of snapshot.surfaces){names.push(o.name);obstacles.push({name:o.name,shape:new R.TriMesh(new Float32Array(o.vertices),new Uint32Array(o.indices)),box:new T.Box3().setFromArray(o.vertices)});}
p.fixed.traverse(o=>{if(!o.isMesh)return;const g=o.geometry.clone().applyMatrix4(o.matrixWorld);obstacles.push({name:'plunger-fixed/'+o.name,shape:new R.TriMesh(g.attributes.position.array,g.index?g.index.array:new Uint32Array(Array.from({length:g.attributes.position.count},(_,i)=>i))),box:new T.Box3().setFromObject(o)});g.dispose();});
const game=await PinballPhysics.create();game.world.updateSceneQueries();const physicsWitnesses=new Map();let physicsQueries=0;
const handles=new Map(game.plungerFitContacts.map(o=>[o.collider.handle,o.name]));
function add(o,indices,suffix){const a=o.geometry.attributes.position,vs=[];for(const i of indices){let v=new T.Vector3().fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld);vs.push(v.x,v.y,v.z);}const shape=new R.ConvexPolyhedron(new Float32Array(vs));parts.push({name:o.name+suffix,shape,box:new T.Box3().setFromArray(vs)});}
const movingMeshes=[];p.moving.traverse(o=>{if(o.isMesh)movingMeshes.push(o);});
for(const o of movingMeshes){
 const g=o.geometry,points=g.parameters.points;
 if(points){const n=points.length,s=g.parameters.segments;
  if(points[0].x>0){
   // Each ring sector is an exact convex wedge; no filled annular bore.
   for(let k=0;k<s;k++)add(o,[k*n,k*n+1,k*n+2,k*n+3,(k+1)*n,(k+1)*n+1,(k+1)*n+2,(k+1)*n+3],'/sector'+k);
  }else for(let j=0;j<n-1;j++){if(Math.abs(points[j+1].y-points[j].y)<1e-8)continue;const ids=[];for(let k=0;k<=s;k++)ids.push(k*n+j,k*n+j+1);add(o,ids,'/frustum'+j);}
 }else add(o,Array.from({length:g.attributes.position.count},(_,i)=>i),'');
}
const witnesses=new Map();let queries=0;
for(let i=0;i<=100;i++){const shift=new T.Vector3(0,0,.32*i/100),pos={x:0,y:0,z:shift.z};for(const a of parts){const b=a.box.clone().translate(shift);for(const target of obstacles){if(!b.intersectsBox(target.box))continue;queries++;const contact=a.shape.contactShape(pos,identity,target.shape,zero,identity,0);if(contact&&contact.distance< -1e-6){const key=target.name;const existing=witnesses.get(key);const w={obstacle:target.name,movingPart:a.name,pull:i/100,penetration:-contact.distance,movingPoint:contact.point1,obstaclePoint:contact.point2};if(!existing||w.penetration>existing.penetration)witnesses.set(key,w);}}}}
for(let i=0;i<=100;i++){const pos={x:0,y:0,z:.32*i/100};for(const a of parts){physicsQueries++;game.world.intersectionsWithShape(pos,identity,a.shape,collider=>{if(collider.isSensor()||collider.handle===game.ballCollider.handle||collider.handle===game.plungerStop.handle)return true;const contact=collider.contactShape(a.shape,pos,identity,0);if(contact&&contact.distance< -1e-5){const name=handles.get(collider.handle)??'historical-handle-'+collider.handle,key=name+'|'+a.name,w={obstacle:name,movingPart:a.name,pull:i/100,penetration:-contact.distance,obstaclePoint:contact.point1,movingPoint:contact.point2};if(!physicsWitnesses.has(key)||w.penetration>physicsWitnesses.get(key).penetration)physicsWitnesses.set(key,w);}return true;});}}
const result={physicsQueries,physicsWitnesses:[...physicsWitnesses.values()],actualAppNearfieldMeshes:snapshot.surfaces.length,method:'Rapier actual-app nearfield triangles plus fixed plunger meshes versus lathe-interval frusta, annular sectors, individual knurl boxes and conservative C-clip hull. All moving meshes sampled; deforming springs are checked separately. Candidate physics queries exclude sensors, ball and the original moving tip collider. No whole-knob convexification.',strokeSamples:101,queries,convexParts:parts.length,witnesses:[...witnesses.values()],noWitness:names.filter(n=>!witnesses.has(n)),status:witnesses.size||physicsWitnesses.size?'Interference found; blocked':'No tested visual/physics interference at 101 poses'};fs.writeFileSync(new URL('./narrowphase.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));p.dispose();c.dispose();game.dispose();
