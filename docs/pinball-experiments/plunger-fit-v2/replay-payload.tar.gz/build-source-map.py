from pathlib import Path
import json,hashlib,os,re
root=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent
first=root/'docs/pinball-experiments/plunger-fit-preflight'
s=(first/'plunger-prototype.mjs').read_text().replace('../../../web/js/pinball/layout.mjs','../layout.mjs').replace('../../../web/js/vendor/three-0.180.0/three.module.min.js','../../vendor/three-0.180.0/three.module.min.js')
s=s.replace('[.108,.045],[.114,.060],[.115,.075],\n      [.108,.094],[.082,.108],[.040,.118],[0,.120]]','[.108,.045],[.114,.055],[.115,.065],\n      [.110,.075],[.090,.082],[.060,.092],[0,.100]]')
s=s.replace('.024,"dark",this.knob,.063)', '.024,"dark",this.knob,.052)').replace('.075,Math.cos(angle)*.116','.062,Math.cos(angle)*.116')
ref=(root/'web/js/pinball/components/reference-cabinet.mjs').read_text()
ref=ref.replace('const points=[[.58,5.05]', 'const channelEdge=side===1?2.375:2.45;\n      const points=[[.58,5.05]').replace('[2.45,5.53],[2.45,5.68]','[channelEdge,5.53],[channelEdge,5.68]')
ref=ref.replace("2.08,.20,.045,side*1.39,.13,5.66", "side===1?2.022:2.08,.20,.045,side===1?1.361:side*1.39,.13,5.66")
ref=ref.replace("W*2-.38,.34,.06,-.12,.25,L-.15", "W*2-.448,.34,.06,-.154,.25,L-.15")
ref=ref.replace("p.mesh.rotation.x=-Math.PI/2;", "p.mesh.rotation.x=-Math.PI/2;p.mesh.material.polygonOffset=true;p.mesh.material.polygonOffsetFactor=-1;p.mesh.material.polygonOffsetUnits=-1;")
cab=(root/'web/js/pinball/components/cabinet.mjs').read_text()
physics=(root/'web/js/pinball/physics.mjs').read_text()
physics="import {plungerFitFixedSurfaces, PLUNGER_FIT_FRONT_TIMBER} from './plunger-fit-contact.mjs';\n"+physics
old='this.box(SHOOTER_LAYOUT.x, .3, SHOOTER_LAYOUT.frontZ, .27, .4, .08);'
new='''// Explicit prototype contact-contract change: replace the unrendered stop
    // with the actual shooter-side front timber; retain every other obstacle.
    const front=PLUNGER_FIT_FRONT_TIMBER;
    this.box(...front.center,...front.halfExtents);
'''
append='''
    // New fixed contacts append after all historical bodies, reset and fasteners.
    this.plungerFitContacts=plungerFitFixedSurfaces().map(surface=>({name:surface.name,
      collider:this.world.createCollider(R.ColliderDesc.trimesh(new Float32Array(surface.vertices),new Uint32Array(surface.indices)).setFriction(.35).setRestitution(.02))}));'''
physics=physics.replace('    this.boardFastenerContacts=appendBoardEdgeFasteners(this.world,R);','    this.boardFastenerContacts=appendBoardEdgeFasteners(this.world,R);'+append)
assert old in physics;physics=physics.replace(old,new)
helper='''import * as T from '../vendor/three-0.180.0/three.module.min.js';
import {MechanicalPlunger,fixedContactSurfaces} from './components/plunger.mjs';
import {MechanicalCabinet} from './components/cabinet.mjs';
import {SHOOTER_LAYOUT,TABLE} from './layout.mjs';
// Measured subsection of the actual timber, not an invisible substitute wall.
export const PLUNGER_FIT_FRONT_TIMBER=Object.freeze({center:[2.53,-.56,6.23],halfExtents:[.27,.84,.08]});
export const PLUNGER_FIT_APRON_NAMES=Object.freeze(['formed-apron-wing-1','apron-folded-front-1','front-hazard-apron','front-folded-cross-rail']);
export function shooterSurfaceSubset(vertices,indices,minX=2.315){
 const out=[],faces=[];
 for(let i=0;i<indices.length;i+=3){let polygon=indices.slice(i,i+3).map(index=>vertices.slice(index*3,index*3+3)),clipped=[];
  for(let j=0;j<polygon.length;j++){const a=polygon[j],b=polygon[(j+1)%polygon.length],insideA=a[0]>=minX,insideB=b[0]>=minX;
   if(insideA)clipped.push(a);
   if(insideA!==insideB){const t=(minX-a[0])/(b[0]-a[0]);clipped.push([minX,a[1]+t*(b[1]-a[1]),a[2]+t*(b[2]-a[2])]);}
  }
  for(let j=1;j<clipped.length-1;j++)for(const v of [clipped[0],clipped[j],clipped[j+1]]){faces.push(out.length/3);out.push(...v);}
 }
 return {vertices:out,indices:faces,scope:'Original surface triangles clipped to X >= 2.315; no new closure faces'};
}
export function plungerFitFixedSurfaces(){
 const p=new MechanicalPlunger(),c=new MechanicalCabinet();p.root.position.set(SHOOTER_LAYOUT.x,.175,SHOOTER_LAYOUT.restZ);c.root.position.z=TABLE.centerZ;c.root.updateMatrixWorld(true);
 const surfaces=fixedContactSurfaces(p);
 for(const name of PLUNGER_FIT_APRON_NAMES){const mesh=c.root.getObjectByName(name),g=mesh.geometry.clone().applyMatrix4(mesh.matrixWorld);surfaces.push({name,...shooterSurfaceSubset(Array.from(g.attributes.position.array),g.index?Array.from(g.index.array):Array.from({length:g.attributes.position.count},(_,i)=>i)),shape:'trimesh'});g.dispose();}
 p.dispose();c.dispose();return surfaces;
}
'''
sources={'/web/js/pinball/components/plunger.mjs':s,'/web/js/pinball/components/reference-cabinet.mjs':ref,'/web/js/pinball/components/cabinet.mjs':cab,'/web/js/pinball/physics.mjs':physics,'/web/js/pinball/plunger-fit-contact.mjs':helper}
(out/'runtime-source-map.json').write_text(json.dumps(sources,indent=2)+'\n')
# Executable local mirrors retain the frozen module content; only imports change.
for name,source in sources.items():
 def resolve(m):
  spec=m.group(2)
  if not spec.startswith('.'):return m.group(0)
  target=(root/name.lstrip('/')).parent/spec;target=target.resolve();url='/'+str(target.relative_to(root))
  destination=out/Path(url).name if url in sources else target
  rel=os.path.relpath(destination,out);rel=rel if rel.startswith('.') else './'+rel
  return m.group(1)+rel+m.group(3)
 source=re.sub(r"(from [\"'])([^\"']+)([\"'])",resolve,source)
 (out/Path(name).name).write_text(source)
manifest={'baselineRuntime':'71245b2','archiveBase':'8e73a0a','status':'isolated second candidate; static gates pending','sources':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in sources.items()},'contractChanges':['Replace unrendered shooter front stop with matching actual timber subsection','Add shared exact fixed plunger/cradle/fastener and reformed apron trimeshes'],'preserved':['Tip datum','Shaft axis and length','Pull .32','Knob front seat -.055','Spring kinematics','Keyboard controls','Launch force']}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
