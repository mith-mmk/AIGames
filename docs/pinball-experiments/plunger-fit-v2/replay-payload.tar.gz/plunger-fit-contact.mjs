import * as T from '../../../web/js/vendor/three-0.180.0/three.module.min.js';
import {MechanicalPlunger,fixedContactSurfaces} from './plunger.mjs';
import {MechanicalCabinet} from './cabinet.mjs';
import {SHOOTER_LAYOUT,TABLE} from '../../../web/js/pinball/layout.mjs';
// Measured subsection of the actual timber, not an invisible substitute wall.
export const PLUNGER_FIT_FRONT_TIMBER=Object.freeze({center:[2.53,-.56,6.23],halfExtents:[.27,.84,.08]});
export const PLUNGER_FIT_APRON_NAMES=Object.freeze(['formed-apron-wing-1','apron-folded-front-1','front-hazard-apron','front-folded-cross-rail']);
export function shooterSurfaceSubset(vertices,indices,minX=2.315){
 const out=[],faces=[];
 for(let i=0;i<indices.length;i+=3){let polygon=indices.slice(i,i+3).map(index=>vertices.slice(index*3,index*3+3)),clipped=[];
  for(let j=0;j<polygon.length;j++){const a=polygon[j],b=polygon[(j+1)%polygon.length],insideA=a[0]>=minX,insideB=b[0]>=minX;
   if(insideA)clipped.push(a);
   if(insideA!==insideB){const t=(minX-a[0])/(b[0]-a[0]);clipped.push([minX,a[1]+t*(b[1]-a[1]),a[2]+t*(b[2]-a[2])]);}
  }
  for(let j=1;j<clipped.length-1;j++)for(const v of [clipped[0],clipped[j],clipped[j+1]]){faces.push(out.length/3);out.push(...v);}
 }
 return {vertices:out,indices:faces,scope:'Original surface triangles clipped to X >= 2.315; no new closure faces'};
}
export function plungerFitFixedSurfaces(){
 const p=new MechanicalPlunger(),c=new MechanicalCabinet();p.root.position.set(SHOOTER_LAYOUT.x,.175,SHOOTER_LAYOUT.restZ);c.root.position.z=TABLE.centerZ;c.root.updateMatrixWorld(true);
 const surfaces=fixedContactSurfaces(p);
 for(const name of PLUNGER_FIT_APRON_NAMES){const mesh=c.root.getObjectByName(name),g=mesh.geometry.clone().applyMatrix4(mesh.matrixWorld);surfaces.push({name,...shooterSurfaceSubset(Array.from(g.attributes.position.array),g.index?Array.from(g.index.array):Array.from({length:g.attributes.position.count},(_,i)=>i)),shape:'trimesh'});g.dispose();}
 p.dispose();c.dispose();return surfaces;
}
